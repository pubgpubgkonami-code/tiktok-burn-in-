package com.example.oledblackcover

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class CoverService : Service() {
    private var windowManager: WindowManager? = null
    private var cover: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> removeCover()
            ACTION_START -> {
                val x = intent.getIntExtra("x", 850)
                val y = intent.getIntExtra("y", 1750)
                val w = intent.getIntExtra("w", 120)
                val h = intent.getIntExtra("h", 150)
                showCover(x, y, w, h)
            }
        }
        return START_NOT_STICKY
    }

    private fun showCover(x: Int, y: Int, w: Int, h: Int) {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        removeCover()
        // Pure black, opaque; NOT_TOUCHABLE allows interaction with TikTok below.
        cover = View(this).apply { setBackgroundColor(Color.BLACK) }
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            w.coerceAtLeast(1), h.coerceAtLeast(1), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = x.coerceAtLeast(0)
            y = y.coerceAtLeast(0)
        }
        windowManager?.addView(cover, params)
    }

    private fun removeCover() {
        try { cover?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        cover = null
    }

    override fun onDestroy() { removeCover(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.example.oledblackcover.START"
        const val ACTION_STOP = "com.example.oledblackcover.STOP"
    }
}
