package com.example.oledblackcover

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var xSeek: SeekBar
    private lateinit var ySeek: SeekBar
    private lateinit var wSeek: SeekBar
    private lateinit var hSeek: SeekBar
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "OLED Black Cover"
            textSize = 24f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Set a pure-black rectangle over a screen area. Adjust its position and size here, then start it. The overlay is non-touchable, so taps pass through to TikTok underneath."
            textSize = 15f; setTextColor(Color.DKGRAY); setPadding(0, 12, 0, 18)
        })
        xSeek = addSlider(root, "Horizontal position", 0, 1000, 850)
        ySeek = addSlider(root, "Vertical position", 0, 2000, 1750)
        wSeek = addSlider(root, "Width", 30, 700, 120)
        hSeek = addSlider(root, "Height", 30, 500, 150)
        summary = TextView(this).apply { setTextColor(Color.BLACK); textSize = 14f; setPadding(0, 10, 0, 10) }
        root.addView(summary)
        val permission = Button(this).apply {
            text = "1. Allow display over other apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        root.addView(permission)
        root.addView(Button(this).apply {
            text = "2. Start / update black cover"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Allow overlay permission first.", Toast.LENGTH_LONG).show()
                } else {
                    val i = Intent(this@MainActivity, CoverService::class.java).apply {
                        action = CoverService.ACTION_START
                        putExtra("x", value(xSeek))
                        putExtra("y", value(ySeek))
                        putExtra("w", value(wSeek))
                        putExtra("h", value(hSeek))
                    }
                    startService(i)
                    Toast.makeText(this@MainActivity, "Black cover started. Return to TikTok.", Toast.LENGTH_SHORT).show()
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Stop / remove black cover"
            setOnClickListener { startService(Intent(this@MainActivity, CoverService::class.java).setAction(CoverService.ACTION_STOP)) }
        })
        root.addView(TextView(this).apply {
            text = "\nNote: coordinates are approximate screen pixels and may need adjustment. This is a black rectangle, not icon-aware masking. It may cover nearby content. It cannot guarantee prevention of OLED burn-in."
            textSize = 13f; setTextColor(Color.DKGRAY); setPadding(0, 12, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
        listOf(xSeek, ySeek, wSeek, hSeek).forEach { it.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { updateSummary() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }) }
        updateSummary()
    }

    private fun addSlider(root: LinearLayout, title: String, min: Int, max: Int, initial: Int): SeekBar {
        root.addView(TextView(this).apply { text = title; textSize = 14f; setTextColor(Color.BLACK); setPadding(0, 8, 0, 0) })
        return SeekBar(this).also {
            it.max = max - min
            it.progress = initial - min
            it.tag = min
            // Store true value via offset helpers below
            root.addView(it)
        }.also { seek ->
            // Wrap the offset into progress reads by using max/initial as actual values isn't convenient;
            // actual values are normalized in value() using tag.
        }
    }

    private fun value(seek: SeekBar): Int = (seek.tag as? Int ?: 0) + seek.progress

    private fun updateSummary() {
        if (!::summary.isInitialized) return
        summary.text = "Current settings: X=${value(xSeek)}, Y=${value(ySeek)}, width=${value(wSeek)}, height=${value(hSeek)}"
    }

    override fun onResume() { super.onResume() }
}
